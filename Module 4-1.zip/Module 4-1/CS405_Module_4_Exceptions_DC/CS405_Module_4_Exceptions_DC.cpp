//Dylan Coulter
//CS405
//Module 4 - Assignment- Exceptions

// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

//This is custom exception that is derived from std::exception also uses _NOEXCEPT
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom exception occurred.";
    }
};


bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;
    //Code added to throw a standard exception
    throw std::runtime_error("Standard exception has occurred");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    //Added code Implementing Try/Catch
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    //Added code to catch a standard exception
    catch (std::exception& e)
    {
        std::cout << "Standard exception: " << e.what() << std::endl;
    }
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    //Added code that will catch the custom exception in main
    throw CustomException();
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    //Added code that will throw an exception for divide by zero
    if (den == 0) {
        throw std::runtime_error("Division by zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;
    try{
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error& e) {
        std::cout << "Runtime Error Has Occurred: " << e.what() << std::endl;
    }
}

int main()
{
    try 
    {
        std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    do_division();
    do_custom_application_logic();
}

//Added code to catch custom exception in main
    catch (CustomException& e)
    {
    //Added code to ouytput a custom exception has been caught
        std::cout << "Custom Exception Has Been Caught!" << std::endl;
    }
    catch (std::exception& e)
    {
        //Added code to output a standard exception has been caught
        std::cout << "Standard Exception Has Been Caught!" << std::endl;
    }
    catch (...)
    {
        //Added code to output an unknown exception has been caught
        std::cout << "Unknown Exception Has Been Caught" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu